﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.NewsTXT = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BASE = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OUT = New System.Windows.Forms.TextBox()
        Me.TMP1 = New System.Windows.Forms.TextBox()
        Me.TMP2 = New System.Windows.Forms.TextBox()
        Me.TMP3 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.NsGroupBox5 = New Durotans_Wille.NSGroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.NsProgressBar2 = New Durotans_Wille.NSProgressBar()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.STG = New Durotans_Wille.NSTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.NsButton5 = New Durotans_Wille.NSButton()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NsTextBox2 = New Durotans_Wille.NSTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NsTextBox1 = New Durotans_Wille.NSTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.NsProgressBar1 = New Durotans_Wille.NSProgressBar()
        Me.NsButton2 = New Durotans_Wille.NSButton()
        Me.NsRadioButton3 = New Durotans_Wille.NSRadioButton()
        Me.NsRadioButton2 = New Durotans_Wille.NSRadioButton()
        Me.NsRadioButton1 = New Durotans_Wille.NSRadioButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.NsGroupBox4 = New Durotans_Wille.NSGroupBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ButtonBlue4 = New Durotans_Wille.ButtonBlue()
        Me.RLIST = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Button1 = New Durotans_Wille.ButtonBlue2()
        Me.NsGroupBox2 = New Durotans_Wille.NSGroupBox()
        Me.NsGroupBox3 = New Durotans_Wille.NSGroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NsSeperator1 = New Durotans_Wille.NSSeperator()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NsOnOffBox1 = New Durotans_Wille.NSOnOffBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NsGroupBox1 = New Durotans_Wille.NSGroupBox()
        Me.NsOnOffBox2 = New Durotans_Wille.NSOnOffBox()
        Me.ButtonBlue5 = New Durotans_Wille.ButtonBlue()
        Me.STG1 = New Durotans_Wille.ButtonBlue()
        Me.STG2 = New Durotans_Wille.ButtonBlue()
        Me.ButtonBlue3 = New Durotans_Wille.ButtonBlue()
        Me.ButtonBlue1 = New Durotans_Wille.ButtonBlue()
        Me.Panel2.SuspendLayout
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout
        Me.NsGroupBox5.SuspendLayout
        Me.STG.SuspendLayout
        Me.TabPage1.SuspendLayout
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout
        Me.TabPage3.SuspendLayout
        Me.NsGroupBox4.SuspendLayout
        Me.TabPage4.SuspendLayout
        Me.NsGroupBox3.SuspendLayout
        Me.NsGroupBox1.SuspendLayout
        Me.SuspendLayout
        '
        'Timer1
        '
        '
        'NewsTXT
        '
        Me.NewsTXT.AutoSize = True
        Me.NewsTXT.BackColor = System.Drawing.Color.Transparent
        Me.NewsTXT.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewsTXT.Location = New System.Drawing.Point(20, 56)
        Me.NewsTXT.Name = "NewsTXT"
        Me.NewsTXT.Size = New System.Drawing.Size(24, 16)
        Me.NewsTXT.TabIndex = 2
        Me.NewsTXT.Text = "...."
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.BASE)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.NewsTXT)
        Me.Panel2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel2.Location = New System.Drawing.Point(183, 28)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(476, 284)
        Me.Panel2.TabIndex = 0
        '
        'BASE
        '
        Me.BASE.Location = New System.Drawing.Point(55, 85)
        Me.BASE.Multiline = True
        Me.BASE.Name = "BASE"
        Me.BASE.ReadOnly = True
        Me.BASE.Size = New System.Drawing.Size(224, 97)
        Me.BASE.TabIndex = 12
        Me.BASE.Text = resources.GetString("BASE.Text")
        Me.BASE.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(20, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(184, 36)
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'OUT
        '
        Me.OUT.Location = New System.Drawing.Point(518, 404)
        Me.OUT.Multiline = True
        Me.OUT.Name = "OUT"
        Me.OUT.ReadOnly = True
        Me.OUT.Size = New System.Drawing.Size(10, 10)
        Me.OUT.TabIndex = 11
        Me.OUT.Visible = False
        '
        'TMP1
        '
        Me.TMP1.Location = New System.Drawing.Point(518, 404)
        Me.TMP1.Multiline = True
        Me.TMP1.Name = "TMP1"
        Me.TMP1.ReadOnly = True
        Me.TMP1.Size = New System.Drawing.Size(10, 10)
        Me.TMP1.TabIndex = 12
        Me.TMP1.Visible = False
        '
        'TMP2
        '
        Me.TMP2.Location = New System.Drawing.Point(518, 404)
        Me.TMP2.Multiline = True
        Me.TMP2.Name = "TMP2"
        Me.TMP2.ReadOnly = True
        Me.TMP2.Size = New System.Drawing.Size(10, 10)
        Me.TMP2.TabIndex = 13
        Me.TMP2.Visible = False
        '
        'TMP3
        '
        Me.TMP3.Location = New System.Drawing.Point(518, 404)
        Me.TMP3.Multiline = True
        Me.TMP3.Name = "TMP3"
        Me.TMP3.ReadOnly = True
        Me.TMP3.Size = New System.Drawing.Size(10, 10)
        Me.TMP3.TabIndex = 14
        Me.TMP3.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.WebBrowser1)
        Me.Panel1.Location = New System.Drawing.Point(183, 28)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(476, 284)
        Me.Panel1.TabIndex = 13
        Me.Panel1.Visible = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.AllowNavigation = False
        Me.WebBrowser1.Location = New System.Drawing.Point(0, -16)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.ScrollBarsEnabled = False
        Me.WebBrowser1.Size = New System.Drawing.Size(476, 300)
        Me.WebBrowser1.TabIndex = 0
        Me.WebBrowser1.Url = New System.Uri("http://login-warcrywow.sytes.net/wow/launcher/index.html", System.UriKind.Absolute)
        '
        'NsGroupBox5
        '
        Me.NsGroupBox5.Controls.Add(Me.Label11)
        Me.NsGroupBox5.Controls.Add(Me.NsProgressBar2)
        Me.NsGroupBox5.Controls.Add(Me.Label10)
        Me.NsGroupBox5.Controls.Add(Me.Label9)
        Me.NsGroupBox5.DrawSeperator = False
        Me.NsGroupBox5.Location = New System.Drawing.Point(180, 323)
        Me.NsGroupBox5.Name = "NsGroupBox5"
        Me.NsGroupBox5.Size = New System.Drawing.Size(339, 80)
        Me.NsGroupBox5.SubTitle = ""
        Me.NsGroupBox5.TabIndex = 15
        Me.NsGroupBox5.Text = "NsGroupBox5"
        Me.NsGroupBox5.Title = ""
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(23, 56)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "0 MB | 0 MB"
        '
        'NsProgressBar2
        '
        Me.NsProgressBar2.Location = New System.Drawing.Point(23, 37)
        Me.NsProgressBar2.Maximum = 100
        Me.NsProgressBar2.Minimum = 0
        Me.NsProgressBar2.Name = "NsProgressBar2"
        Me.NsProgressBar2.Size = New System.Drawing.Size(297, 10)
        Me.NsProgressBar2.TabIndex = 7
        Me.NsProgressBar2.Text = "NsProgressBar2"
        Me.NsProgressBar2.Value = 0
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(85, 12)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "0 %"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label9.Location = New System.Drawing.Point(20, 12)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Fortschritt:"
        '
        'STG
        '
        Me.STG.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.STG.Controls.Add(Me.TabPage1)
        Me.STG.Controls.Add(Me.TabPage2)
        Me.STG.Controls.Add(Me.TabPage3)
        Me.STG.Controls.Add(Me.TabPage4)
        Me.STG.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.STG.ItemSize = New System.Drawing.Size(28, 115)
        Me.STG.Location = New System.Drawing.Point(681, 25)
        Me.STG.Multiline = True
        Me.STG.Name = "STG"
        Me.STG.SelectedIndex = 0
        Me.STG.Size = New System.Drawing.Size(485, 302)
        Me.STG.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.STG.TabIndex = 5
        Me.STG.Visible = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.NsButton5)
        Me.TabPage1.Controls.Add(Me.TrackBar1)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.NsTextBox2)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.NsTextBox1)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Location = New System.Drawing.Point(119, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(362, 294)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Login Infos"
        '
        'NsButton5
        '
        Me.NsButton5.Location = New System.Drawing.Point(214, 229)
        Me.NsButton5.Name = "NsButton5"
        Me.NsButton5.Size = New System.Drawing.Size(127, 46)
        Me.NsButton5.TabIndex = 7
        Me.NsButton5.Text = "    Übernehmen"
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(23, 159)
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(277, 45)
        Me.TrackBar1.TabIndex = 6
        Me.TrackBar1.Value = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(99, 124)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 17)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "7000"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label7.Location = New System.Drawing.Point(20, 124)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 17)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Login Zeit:"
        '
        'NsTextBox2
        '
        Me.NsTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox2.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsTextBox2.Location = New System.Drawing.Point(99, 68)
        Me.NsTextBox2.MaxLength = 32767
        Me.NsTextBox2.Multiline = False
        Me.NsTextBox2.Name = "NsTextBox2"
        Me.NsTextBox2.ReadOnly = False
        Me.NsTextBox2.Size = New System.Drawing.Size(201, 27)
        Me.NsTextBox2.TabIndex = 3
        Me.NsTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox2.UseSystemPasswordChar = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label6.Location = New System.Drawing.Point(24, 68)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Passwort:"
        '
        'NsTextBox1
        '
        Me.NsTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsTextBox1.Location = New System.Drawing.Point(99, 21)
        Me.NsTextBox1.MaxLength = 32767
        Me.NsTextBox1.Multiline = False
        Me.NsTextBox1.Name = "NsTextBox1"
        Me.NsTextBox1.ReadOnly = False
        Me.NsTextBox1.Size = New System.Drawing.Size(201, 27)
        Me.NsTextBox1.TabIndex = 1
        Me.NsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox1.UseSystemPasswordChar = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label5.Location = New System.Drawing.Point(27, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Benutzer:"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.NsProgressBar1)
        Me.TabPage2.Controls.Add(Me.NsButton2)
        Me.TabPage2.Controls.Add(Me.NsRadioButton3)
        Me.TabPage2.Controls.Add(Me.NsRadioButton2)
        Me.TabPage2.Controls.Add(Me.NsRadioButton1)
        Me.TabPage2.Location = New System.Drawing.Point(119, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(362, 294)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Extras"
        '
        'NsProgressBar1
        '
        Me.NsProgressBar1.Location = New System.Drawing.Point(181, 166)
        Me.NsProgressBar1.Maximum = 100
        Me.NsProgressBar1.Minimum = 0
        Me.NsProgressBar1.Name = "NsProgressBar1"
        Me.NsProgressBar1.Size = New System.Drawing.Size(91, 10)
        Me.NsProgressBar1.TabIndex = 4
        Me.NsProgressBar1.Text = "NsProgressBar1"
        Me.NsProgressBar1.Value = 0
        '
        'NsButton2
        '
        Me.NsButton2.Location = New System.Drawing.Point(181, 131)
        Me.NsButton2.Name = "NsButton2"
        Me.NsButton2.Size = New System.Drawing.Size(91, 29)
        Me.NsButton2.TabIndex = 3
        Me.NsButton2.Text = "  Ausführen"
        '
        'NsRadioButton3
        '
        Me.NsRadioButton3.Checked = False
        Me.NsRadioButton3.Location = New System.Drawing.Point(28, 85)
        Me.NsRadioButton3.Name = "NsRadioButton3"
        Me.NsRadioButton3.Size = New System.Drawing.Size(244, 23)
        Me.NsRadioButton3.TabIndex = 2
        Me.NsRadioButton3.Text = " Login Script löschen"
        '
        'NsRadioButton2
        '
        Me.NsRadioButton2.Checked = False
        Me.NsRadioButton2.Location = New System.Drawing.Point(28, 56)
        Me.NsRadioButton2.Name = "NsRadioButton2"
        Me.NsRadioButton2.Size = New System.Drawing.Size(244, 23)
        Me.NsRadioButton2.TabIndex = 1
        Me.NsRadioButton2.Text = " Client Konfiguration löschen"
        '
        'NsRadioButton1
        '
        Me.NsRadioButton1.Checked = True
        Me.NsRadioButton1.Location = New System.Drawing.Point(28, 27)
        Me.NsRadioButton1.Name = "NsRadioButton1"
        Me.NsRadioButton1.Size = New System.Drawing.Size(203, 23)
        Me.NsRadioButton1.TabIndex = 0
        Me.NsRadioButton1.Text = " Cache Verzeichnis löschen"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.NsGroupBox4)
        Me.TabPage3.Controls.Add(Me.Label14)
        Me.TabPage3.Controls.Add(Me.Label13)
        Me.TabPage3.Location = New System.Drawing.Point(119, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(362, 294)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Charaktere"
        '
        'NsGroupBox4
        '
        Me.NsGroupBox4.Controls.Add(Me.ListBox1)
        Me.NsGroupBox4.DrawSeperator = False
        Me.NsGroupBox4.Location = New System.Drawing.Point(28, 55)
        Me.NsGroupBox4.Name = "NsGroupBox4"
        Me.NsGroupBox4.Size = New System.Drawing.Size(303, 216)
        Me.NsGroupBox4.SubTitle = ""
        Me.NsGroupBox4.TabIndex = 3
        Me.NsGroupBox4.Text = "NsGroupBox4"
        Me.NsGroupBox4.Title = ""
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.Black
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 19
        Me.ListBox1.Location = New System.Drawing.Point(3, 3)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(296, 209)
        Me.ListBox1.TabIndex = 0
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label14.Location = New System.Drawing.Point(163, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(90, 20)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Asgard Fun"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(14, 19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(152, 17)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Meine Charaktere auf:"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.ButtonBlue4)
        Me.TabPage4.Controls.Add(Me.RLIST)
        Me.TabPage4.Controls.Add(Me.Label15)
        Me.TabPage4.Location = New System.Drawing.Point(119, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(362, 294)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Realmlist"
        '
        'ButtonBlue4
        '
        Me.ButtonBlue4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue4.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.ButtonBlue4.Image = Nothing
        Me.ButtonBlue4.Location = New System.Drawing.Point(238, 191)
        Me.ButtonBlue4.Name = "ButtonBlue4"
        Me.ButtonBlue4.NoRounding = False
        Me.ButtonBlue4.Size = New System.Drawing.Size(92, 30)
        Me.ButtonBlue4.TabIndex = 4
        Me.ButtonBlue4.Text = "Bearbeiten"
        '
        'RLIST
        '
        Me.RLIST.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.RLIST.ForeColor = System.Drawing.Color.White
        Me.RLIST.Location = New System.Drawing.Point(29, 69)
        Me.RLIST.Name = "RLIST"
        Me.RLIST.Size = New System.Drawing.Size(301, 108)
        Me.RLIST.TabIndex = 3
        Me.RLIST.Text = "waiting..."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label15.Location = New System.Drawing.Point(29, 31)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(177, 17)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Aktueller Realmlist Eintrag:"
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.Button1.Image = Nothing
        Me.Button1.Location = New System.Drawing.Point(545, 332)
        Me.Button1.Name = "Button1"
        Me.Button1.NoRounding = False
        Me.Button1.Size = New System.Drawing.Size(105, 68)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Spielen"
        '
        'NsGroupBox2
        '
        Me.NsGroupBox2.DrawSeperator = False
        Me.NsGroupBox2.Location = New System.Drawing.Point(180, 25)
        Me.NsGroupBox2.Name = "NsGroupBox2"
        Me.NsGroupBox2.Size = New System.Drawing.Size(482, 290)
        Me.NsGroupBox2.SubTitle = ""
        Me.NsGroupBox2.TabIndex = 1
        Me.NsGroupBox2.Text = "NsGroupBox2"
        Me.NsGroupBox2.Title = ""
        '
        'NsGroupBox3
        '
        Me.NsGroupBox3.Controls.Add(Me.Label4)
        Me.NsGroupBox3.Controls.Add(Me.NsSeperator1)
        Me.NsGroupBox3.Controls.Add(Me.Label3)
        Me.NsGroupBox3.Controls.Add(Me.NsOnOffBox1)
        Me.NsGroupBox3.Controls.Add(Me.Label2)
        Me.NsGroupBox3.Controls.Add(Me.Label16)
        Me.NsGroupBox3.Controls.Add(Me.Label1)
        Me.NsGroupBox3.DrawSeperator = False
        Me.NsGroupBox3.Location = New System.Drawing.Point(12, 266)
        Me.NsGroupBox3.Name = "NsGroupBox3"
        Me.NsGroupBox3.Size = New System.Drawing.Size(150, 137)
        Me.NsGroupBox3.SubTitle = ""
        Me.NsGroupBox3.TabIndex = 3
        Me.NsGroupBox3.Text = "NsGroupBox3"
        Me.NsGroupBox3.Title = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.LimeGreen
        Me.Label4.Location = New System.Drawing.Point(71, 91)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "ONLINE"
        '
        'NsSeperator1
        '
        Me.NsSeperator1.Location = New System.Drawing.Point(3, 39)
        Me.NsSeperator1.Name = "NsSeperator1"
        Me.NsSeperator1.Size = New System.Drawing.Size(141, 10)
        Me.NsSeperator1.TabIndex = 15
        Me.NsSeperator1.Text = "NsSeperator1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.LimeGreen
        Me.Label3.Location = New System.Drawing.Point(71, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "ONLINE"
        '
        'NsOnOffBox1
        '
        Me.NsOnOffBox1.Checked = False
        Me.NsOnOffBox1.Location = New System.Drawing.Point(85, 9)
        Me.NsOnOffBox1.MaximumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.MinimumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.Name = "NsOnOffBox1"
        Me.NsOnOffBox1.Size = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.TabIndex = 15
        Me.NsOnOffBox1.Text = "NsOnOffBox1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(17, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "WORLD:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label16.Location = New System.Drawing.Point(5, 9)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 17)
        Me.Label16.TabIndex = 8
        Me.Label16.Text = "Auto Login:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(23, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "LOGIN:"
        '
        'NsGroupBox1
        '
        Me.NsGroupBox1.Controls.Add(Me.NsOnOffBox2)
        Me.NsGroupBox1.Controls.Add(Me.ButtonBlue5)
        Me.NsGroupBox1.Controls.Add(Me.STG1)
        Me.NsGroupBox1.Controls.Add(Me.STG2)
        Me.NsGroupBox1.Controls.Add(Me.ButtonBlue3)
        Me.NsGroupBox1.Controls.Add(Me.ButtonBlue1)
        Me.NsGroupBox1.DrawSeperator = False
        Me.NsGroupBox1.Location = New System.Drawing.Point(12, 25)
        Me.NsGroupBox1.Name = "NsGroupBox1"
        Me.NsGroupBox1.Size = New System.Drawing.Size(150, 218)
        Me.NsGroupBox1.SubTitle = ""
        Me.NsGroupBox1.TabIndex = 0
        Me.NsGroupBox1.Text = "NsGroupBox1"
        Me.NsGroupBox1.Title = ""
        '
        'NsOnOffBox2
        '
        Me.NsOnOffBox2.Checked = True
        Me.NsOnOffBox2.Location = New System.Drawing.Point(74, 176)
        Me.NsOnOffBox2.MaximumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox2.MinimumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox2.Name = "NsOnOffBox2"
        Me.NsOnOffBox2.Size = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox2.TabIndex = 9
        Me.NsOnOffBox2.Text = "NsOnOffBox2"
        '
        'ButtonBlue5
        '
        Me.ButtonBlue5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue5.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.ButtonBlue5.Image = Nothing
        Me.ButtonBlue5.Location = New System.Drawing.Point(13, 176)
        Me.ButtonBlue5.Name = "ButtonBlue5"
        Me.ButtonBlue5.NoRounding = False
        Me.ButtonBlue5.Size = New System.Drawing.Size(49, 23)
        Me.ButtonBlue5.TabIndex = 13
        Me.ButtonBlue5.Text = "Exit"
        '
        'STG1
        '
        Me.STG1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.STG1.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.STG1.Image = Nothing
        Me.STG1.Location = New System.Drawing.Point(13, 59)
        Me.STG1.Name = "STG1"
        Me.STG1.NoRounding = False
        Me.STG1.Size = New System.Drawing.Size(123, 40)
        Me.STG1.TabIndex = 12
        Me.STG1.Text = "Einstellungen"
        '
        'STG2
        '
        Me.STG2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.STG2.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.STG2.Image = Nothing
        Me.STG2.Location = New System.Drawing.Point(13, 59)
        Me.STG2.Name = "STG2"
        Me.STG2.NoRounding = False
        Me.STG2.Size = New System.Drawing.Size(119, 40)
        Me.STG2.TabIndex = 6
        Me.STG2.Text = "Einstellungen"
        Me.STG2.Visible = False
        '
        'ButtonBlue3
        '
        Me.ButtonBlue3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue3.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.ButtonBlue3.Image = Nothing
        Me.ButtonBlue3.Location = New System.Drawing.Point(13, 13)
        Me.ButtonBlue3.Name = "ButtonBlue3"
        Me.ButtonBlue3.NoRounding = False
        Me.ButtonBlue3.Size = New System.Drawing.Size(123, 40)
        Me.ButtonBlue3.TabIndex = 11
        Me.ButtonBlue3.Text = "Aktualisieren"
        '
        'ButtonBlue1
        '
        Me.ButtonBlue1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue1.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.ButtonBlue1.Image = Nothing
        Me.ButtonBlue1.Location = New System.Drawing.Point(13, 105)
        Me.ButtonBlue1.Name = "ButtonBlue1"
        Me.ButtonBlue1.NoRounding = False
        Me.ButtonBlue1.Size = New System.Drawing.Size(123, 40)
        Me.ButtonBlue1.TabIndex = 4
        Me.ButtonBlue1.Text = "Screenshots"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(677, 422)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.NsGroupBox5)
        Me.Controls.Add(Me.STG)
        Me.Controls.Add(Me.TMP3)
        Me.Controls.Add(Me.TMP2)
        Me.Controls.Add(Me.TMP1)
        Me.Controls.Add(Me.OUT)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.NsGroupBox2)
        Me.Controls.Add(Me.NsGroupBox3)
        Me.Controls.Add(Me.NsGroupBox1)
        Me.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "World of Warcraft | WotLK Patch: 3.3.5a Build 12340"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.NsGroupBox5.ResumeLayout(False)
        Me.NsGroupBox5.PerformLayout
        Me.STG.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout
        Me.NsGroupBox4.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout
        Me.NsGroupBox3.ResumeLayout(False)
        Me.NsGroupBox3.PerformLayout
        Me.NsGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout

    End Sub

    Friend WithEvents NsGroupBox1 As NSGroupBox
    Friend WithEvents NsGroupBox2 As NSGroupBox
    Friend WithEvents NsGroupBox3 As NSGroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents STG As NSTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents NsProgressBar1 As NSProgressBar
    Friend WithEvents NsButton2 As NSButton
    Friend WithEvents NsRadioButton3 As NSRadioButton
    Friend WithEvents NsRadioButton2 As NSRadioButton
    Friend WithEvents NsRadioButton1 As NSRadioButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents NewsTXT As Label
    Friend WithEvents NsButton5 As NSButton
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents NsTextBox2 As NSTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents NsTextBox1 As NSTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents NsGroupBox4 As NSGroupBox
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents RLIST As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Button1 As ButtonBlue2
    Friend WithEvents ButtonBlue1 As ButtonBlue
    Friend WithEvents STG2 As ButtonBlue
    Friend WithEvents ButtonBlue3 As ButtonBlue
    Friend WithEvents BASE As TextBox
    Friend WithEvents OUT As TextBox
    Friend WithEvents TMP1 As TextBox
    Friend WithEvents TMP2 As TextBox
    Friend WithEvents TMP3 As TextBox
    Friend WithEvents STG1 As ButtonBlue
    Friend WithEvents NsOnOffBox1 As NSOnOffBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ButtonBlue4 As ButtonBlue
    Friend WithEvents NsSeperator1 As NSSeperator
    Friend WithEvents NsGroupBox5 As NSGroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents NsProgressBar2 As NSProgressBar
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ButtonBlue5 As ButtonBlue
    Friend WithEvents NsOnOffBox2 As NSOnOffBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents WebBrowser1 As WebBrowser
End Class
