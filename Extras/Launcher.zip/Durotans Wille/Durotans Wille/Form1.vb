﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Public Class Form1
    Dim World As New TcpClient
    Private Sub NsButton2_Click(sender As Object, e As EventArgs) Handles NsButton2.Click
        If NsRadioButton1.Checked Then
            Try
                System.IO.Directory.Delete(Application.StartupPath & "\Cache\WDB\deDE\", True)
                NsProgressBar1.Value = 100
                Timer1.Start()
            Catch ex As Exception
                MsgBox("Es befinden sich noch keine Dateien im Cache Verzeichnis.")
            End Try
        End If
        If NsRadioButton3.Checked Then
            Try
                My.Computer.FileSystem.DeleteFile("\Cache\Login.vbs")
                NsProgressBar1.Value = 100
                Timer1.Start()
            Catch ex As Exception
                MsgBox("Die Datei wurde bereits gelöscht!")
            End Try
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        NsProgressBar1.Value = 0
        Timer1.Stop()
    End Sub
    Dim Auth As New TcpClient
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Auth.Connect("213.202.252.11", (3724))
        Catch ex As Exception
            Label3.Text = "OFFLINE"
            Label3.ForeColor = Color.Red
        End Try

        If Auth.Connected Then
            Label3.Text = "ONLINE"
            Label3.ForeColor = Color.LimeGreen
            Auth.Close()
        End If
        Try
            World.Connect("213.202.252.11", (8085))
        Catch ex As Exception
            Label4.Text = "OFFLINE"
            Label4.ForeColor = Color.Red
        End Try

        If World.Connected Then
            Label4.Text = "ONLINE"
            Label4.ForeColor = Color.LimeGreen
            World.Close()
        End If
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\Data\patch-5.mpq") = False Then
            My.Computer.Network.DownloadFile("https://raw.githubusercontent.com/EmuZoneDEV/WotLK_World/master/Extras/patch-5.mpq", Application.StartupPath & "\Data\patch-5.mpq")
        End If
        NsOnOffBox1.Checked = My.Settings.AUTOLGN
        Try
            Dim lesen As String = File.ReadAllText(Application.StartupPath & "\launcher.ini")
            NewsTXT.Text = lesen
        Catch ex As Exception
            NewsTXT.Text = "Keine Internetverbindung!"
        End Try
        Try
            For Each a As String In IO.Directory.GetDirectories(Application.StartupPath & "\WTF\Account\TESS8\Asgard PVP\")
                Dim fi As New IO.FileInfo(a)
                ListBox1.Items.Add(fi.Name)
            Next
        Catch ex As Exception

        End Try
        Try
            Dim lesen As String = File.ReadAllText(Application.StartupPath & "\Data\deDE\realmlist.wtf")
            RLIST.Text = lesen
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If NsOnOffBox1.Checked Then
            Try
                Process.Start(Application.StartupPath & "\Cache\Login.vbs")
                Me.Close()
            Catch ex As Exception
                MsgBox("Das System kann die angeforderte Datei (Wow.exe) nicht finden. Bitte überprüfen Sie die installation des Produkts oder ficken Sie Annika Gränert ijn den Arsch.")
            End Try
        Else
            Try
                Process.Start(Application.StartupPath & "\Wow.exe")
                Me.Close()
            Catch ex As Exception
                MsgBox("Das System kann die angeforderte Datei (Wow.exe) nicht finden. Bitte überprüfen Sie die installation des Produkts.")
            End Try
        End If
    End Sub
    Private Sub STG2_Click_1(sender As Object, e As EventArgs) Handles STG2.Click
        STG1.Visible = True
        STG2.Visible = False
        STG.Visible = False
        Panel2.Visible = True
        Panel1.Visible = True
        NsGroupBox2.Visible = True
        STG.Location = New Point(679, 25)
    End Sub

    Private Sub NsButton5_Click_1(sender As Object, e As EventArgs) Handles NsButton5.Click
        TMP1.Text = BASE.Text.Replace("%USER%", NsTextBox1.Text)
        TMP2.Text = TMP1.Text.Replace("%PASS%", NsTextBox2.Text)
        OUT.Text = TMP2.Text.Replace("%TIME%", Label8.Text)
        Dim Writer As New StreamWriter(Application.StartupPath & "\Cache\Login.vbs", False)
        Writer.Write(OUT.Text)
        Writer.Close()
    End Sub

    Private Sub STG1_Click(sender As Object, e As EventArgs) Handles STG1.Click
        STG1.Visible = False
        STG2.Visible = True
        STG.Visible = True
        Panel2.Visible = False
        Panel1.Visible = False
        NsGroupBox2.Visible = False
        STG.Location = New Point(177, 25)
    End Sub

    Private Sub NsOnOffBox1_CheckedChanged(sender As Object) Handles NsOnOffBox1.CheckedChanged
        If NsOnOffBox1.Checked Then
            My.Settings.AUTOLGN = NsOnOffBox1.Checked
            My.Settings.Save()
        End If
    End Sub

    Private Sub ButtonBlue4_Click(sender As Object, e As EventArgs) Handles ButtonBlue4.Click
        Realmlist.ShowDialog()
    End Sub

    Private Sub ButtonBlue1_Click(sender As Object, e As EventArgs) Handles ButtonBlue1.Click
        Try
            Process.Start(Application.StartupPath & "\Screenshots\")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ButtonBlue3_Click(sender As Object, e As EventArgs) Handles ButtonBlue3.Click
        Me.Refresh()
    End Sub

    Private Sub ButtonBlue5_Click(sender As Object, e As EventArgs) Handles ButtonBlue5.Click
        End
    End Sub

    Private Sub NsOnOffBox2_CheckedChanged(sender As Object) Handles NsOnOffBox2.CheckedChanged
        If NsOnOffBox2.Checked Then
            Panel1.Visible = True
        Else
            Panel1.Visible = False
        End If
    End Sub
End Class
