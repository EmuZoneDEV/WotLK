﻿Imports System.Windows.Forms
Imports System.IO
Public Class Realmlist

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub NsTextBox1_TextChanged(sender As Object, e As EventArgs) Handles NsTextBox1.TextChanged
        Dim Writer As New StreamWriter(Application.StartupPath & "\Data\deDE\realmlist.wtf", False)
        Writer.Write(NsTextBox1.Text)
        Writer.Close()
        Try
            Dim lesen As String = File.ReadAllText(Application.StartupPath & "\Data\deDE\realmlist.wtf")
            Form1.RLIST.Text = lesen
        Catch ex As Exception

        End Try
    End Sub
End Class
